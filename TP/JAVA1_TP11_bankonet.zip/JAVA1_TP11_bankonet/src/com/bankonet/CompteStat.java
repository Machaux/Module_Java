package com.bankonet;

public interface CompteStat {
	
	public float getSolde();

}
