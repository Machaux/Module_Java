package com.bankonet.jdbc;

/**
 * @author sysdeo
 *
 * Exception lev�e lors de l'ex�cution de la m�thode
 * genererNouveauNumeroCompte de la classe ClientDao
 */
public class ErreurCalculException extends Exception {

}